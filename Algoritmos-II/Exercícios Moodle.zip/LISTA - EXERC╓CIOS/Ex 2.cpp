#include<iostream> 
#include<list> 
using namespace std;

int main()
{
     list<int> fila;
     int x;
     
     for(int i = 0; i < 4; i++)
	 {
	 	cin >> x;
	 	fila.push_back(x);
	 }
	
	 while(!fila.empty())
	 {
	 	cout<< *fila.begin() << endl;
	 	fila.pop_front();
	 }
	
	return 0;
}
#include<iostream> 
#include<list> 

using namespace std;

int main()
{
	list<int> est;
	list<int> ved;
	list<int>::iterator p;
	int n;
	int x;
	int op;
	int aux;

	
	cin >> n;
	
	while(n!= 0)
	{
		cin>> op;
		if(op == 1)
		{
          cin >> x;
		  est.push_back(x);	
		}
		else if(op == 2)
		{
			aux = *est.begin();
			est.pop_front();
			ved.push_front(aux);
		}
		n--;
	}
	
	
	cout << "Estoque ";
	for(p = est.begin(); p!= est.end(); p++)
	{
		cout << *p << " ";
	}
	cout << endl;
	cout<< "Venda ";
	for(p = ved.begin(); p!= ved.end(); p++)
	{
		cout << *p << " ";
	}
	return 0;
}
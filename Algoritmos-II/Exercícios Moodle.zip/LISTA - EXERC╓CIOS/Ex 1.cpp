#include<iostream>
#include<list>

using namespace std;

int main()
{

	list<int> pilha; //Ponteiros
	int x; // var aux para leitura dos dados

	// Lendo dados e inserindo na pilha
	for(int i = 0; i < 4; i++)
	{
		cin >> x;
		pilha.push_front(x); // inseri x no in�cio da pilha
	}

	//mostrando e removendo elementos inseridos
	while(!pilha.empty())
	{
		cout << *pilha.begin() << endl; // aponta para o primeiro n� da lista
		pilha.pop_front(); // remove o priomeiro n� da lista
	}



	return 0;
}

#include<iostream>
#include<list>

using namespace std;


bool encontrar(list<float> lista, float x)
{
    list<float>::iterator p;
    
    for(p = lista.begin(); p != lista.end(); p++){
    if(*p == x)
    return true;}
    
    return false;
    
}
int main()
{
    list<float> lista;
    float x;
    float chave;
    
    for(int i = 0; i < 100; i++)
    {
        cin >> x;
        if(x!=0)
        lista.push_front(x);
        else
        i = 101;
    }
    
    cin >> chave;
    
    if(encontrar(lista,chave) == true)
    cout << "Encontrado" << endl;
    else 
    cout << "Nao encontrado" << endl;
    
    
    
    return 0;
}
#include<iostream>
#include<list>

using namespace std;




int main()
{
	list<int> lista1;
	list<int> lista2;
	list<int> lista3;
	list<int>::iterator p1;
	list<int>::iterator p2;

	int l1;
	int l2;



	cin >> l1;
	while(l1 != 0)
	{
		if(l1 != 0)
		{
			lista1.push_back(l1);
		}
		cin >> l1;
	}

	cin >> l2;
	while(l2 != 0)
	{
		if(l2 != 0)
		{
			lista2.push_back(l2);
		}
		cin >> l2;
	}

	cout << endl;


	while(!lista1.empty() || !lista2.empty())
	{
		p1 = lista1.begin();
		p2 = lista2.begin();
		if(*p1 == *p2)
		{
			lista3.push_back(*p1);
			lista1.pop_front();
			lista2.pop_front();
		}
		else
		{
			if(*p1 < *p2)
			{
			
				lista3.push_back(*p1);
				lista1.pop_front();
				
			}
			else
			{
			
				lista3.push_back(*p2);
				lista2.pop_front();
			}
		}


	}

	while(!lista3.empty())
	{
		cout << lista3.front() << " ";
		lista3.pop_front();

	}
	return 0;
}

#include<iostream>
#include<list>

using namespace std;




int soma(list<int> lista)
{
    list<int>::iterator p;
    int soma = 0;
    
    for( p = lista.begin(); p!= lista.end(); p++)
    soma += *p;
    
    return soma;
}



int main()
{
    list<int> lista;
    int x;
    
    for(int i = 0; i < 100; i++)
    {
        cin >> x;
        if(x!= 0)
        lista.push_front(x);
        else 
        i = 101;
    }
    
    cout << soma(lista) << endl;
    
    return 0;
}
#include<iostream>
#include<list>

using namespace std;

int contar(list<int> lista)
{
    list<int>::iterator p;
    int t = 0;
    for(p = lista.begin(); p!= lista.end(); p++)
    t++;
    
    return t;
    
}

int main()
{
    list<int> lista;
    int x;
    
    for(int i = 0; i < 100; i++)
    {
        cin >> x;
        if(x!= 0)
        lista.push_front(x);
        else 
        i = 101;
    }
    
    cout << contar(lista) << endl;
    
    return 0;
}
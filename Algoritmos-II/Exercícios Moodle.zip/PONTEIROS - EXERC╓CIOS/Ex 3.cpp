#include<iostream>

using namespace std;

int main()
{
	int v[100];
	int *p;
	int N;
	int valor;

	cin >> N;

	p = v;

	for(int i = 0; i < N; i++)
	{
		cin >> valor;
		*p = valor;
		p++;
	}

	p = p - N;

	for(int i = 0; i < N; i++)
	{
		cout << *p << " ";
		p++;
	}


	return 0;
}

#include<iostream>
#include<iomanip>

using namespace std;

int main()
{

	int N;
	int *p;
	int n[100];
	int soma = 0;
	float media;

	cin >> N;


	p = new int[N];


	for(int i = 0; i < N; i++)
		cin >> n[i];

	p = n;

	for(int i = 0; i < N; i++)
	{
		soma = soma + *p;
		p++;
	}


	media = soma / (N * 1.00);

	cout << fixed << setprecision(2);
	cout << media << endl;

	return 0;
}

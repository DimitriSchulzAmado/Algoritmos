#include<iostream>


using namespace std;

int main()
{

	int N;
	int *p;
	int n[100];
	int num = 0;

	cin >> N;


	p = new int[N];


	for(int i = 0; i < N; i++)
		cin >> n[i];

	p = n;

	for(int i = 0; i < N; i++)
	{
		if(*p % 2 == 0 && *p > 0)
			num++;

		p++;
	}


	cout << num << endl;
	return 0;
}

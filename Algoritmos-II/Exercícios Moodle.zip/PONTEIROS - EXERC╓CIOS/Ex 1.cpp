#include<iostream> 
#include<iomanip>

using namespace std;

struct dado
{
	float nota[4];
	float media;
};

int main()
{
   dado *valor;
   float soma = 0;
   
   valor = new dado;
   for(int i = 0; i < 4; i++){
   cin >> valor->nota[i];
   soma = soma + valor->nota[i];}
   
   valor->media = (soma)/4;
   
   cout<< fixed<< setprecision(2);
   cout << valor->media << endl;
   
   delete valor; 	
	
	return 0;
}
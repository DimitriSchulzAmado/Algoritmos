#include<iostream>
#include<iomanip>

using namespace std;


struct dado
{
	float nota[4];
	float media;
};



int main()
{
	dado *valor;
	int N;
	float soma = 0;
	float somaM = 0;
	float mediaM;

	cin >> N;

	valor = new dado[N];

	for(int i = 0; i < N; i++)
	{
		for(int Z = 0; Z < 4; Z++)
		{
			cin >> valor[i].nota[Z];
			soma = soma + valor[i].nota[Z];
		}

		valor[i].media = soma / 4;
		somaM = somaM + valor[i].media;

		soma = 0;
	}

	mediaM = somaM / N;

	cout << fixed << setprecision(2);
	cout << mediaM << endl;

	delete []valor;

	return 0;
}

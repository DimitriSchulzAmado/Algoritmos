#include<iostream>
#include<list>


using namespace std;

struct no
{
	int v;
	int peso;
};


void BFS(list<no> adj[], int nV, int s)
{
	int state[100];
	int p[100];
	int u;
	int V;

	for(u = 0; u < nV; u++)
	{
		state[u] = -1;
		p[u] = -1;
	}

	list<int> Q;
	state[s] = 0;
	p[s] = -1;
	Q.push_back(s);

	list<no>::iterator P;

	while(!Q.empty())
	{
		u = Q.front();
		Q.pop_front();
		cout << u << endl;
		for(P = adj[u].begin(); P != adj[u].end(); P++)
		{
			V = P->v;
			cout << u << " " << V << endl;
			if(state[V] == -1)
			{
				state[V] = 0;
				p[V] = u;
				Q.push_back(V);
			}
		}
		state[u] = 1;
	}

}
int main()
{
	int nV;
	int s;
	no aux;
	int u, v, peso;
	list<no> adj[100];

	cin >> nV;
	cin >> s;

	for(int i = 0; i < 101; i++)
	{
		cin >> u >> v >> peso;
		if(u == -1 && v == -1 && peso == -1)
			i = 101;
		else
		{
			aux.v = v;
			aux.peso = peso;
			adj[u].push_back(aux);
			aux.v = u;
			adj[v].push_back(aux);
		}
	}

	BFS(adj, nV, s);

	return 0;
}

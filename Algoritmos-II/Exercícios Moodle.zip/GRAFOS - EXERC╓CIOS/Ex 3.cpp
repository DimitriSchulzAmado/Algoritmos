#include<iostream>
#include<list>
#include<climits>

using namespace std;

struct no
{
	int v;
	int peso;
};
void cria_aresta(list<no> adj[], int u, int v, int p, int Orientado)
{
	no aux;
	aux.v = v;
	aux.peso = p;
	adj[u].push_back(aux);
	if(Orientado == 0)
	{
		aux.v = u;
		adj[v].push_back(aux);
	}
}

void prim(list<no>adj[], int nVertices, int start)
{
	bool intree[100];
	int distance[100];
	int parent[100];
	int V;
	int destino;
	int weight;
	int soma = 0;
	int dist;

	list<no>::iterator p;

	for(int u = 0; u < nVertices; u++)
	{
		intree[u] = false;
		distance[u] = INT_MAX;
		parent[u] = -1;
	}

	distance[start] = 0;
	V = start;
	while(intree[V] == false)
	{
		intree[V] = true;
		for(p = adj[V].begin(); p != adj[V].end(); p++)
		{
			destino = p->v;
			weight = p->peso;
			if(distance[destino] > weight && intree[destino] == false)
			{
				distance[destino] = weight;
				parent[destino] = V;
			}
		}
		V = 0;
		dist = INT_MAX;
		for(int u = 0; u < nVertices; u++)
		{
	      	if(intree[u] == false && dist > distance[u])
			{
				dist = distance[u];
				V = u;
				
			}
			
		
		}
	}
	cout << endl;
	cout << "Arvore Geradora Minima" << endl;
    for(int u = 0; u < nVertices; u++)
	{
         if(parent[u] != -1)   
		 {
	      cout << parent[u] << " " << u << endl;
	      soma += distance[u];
		 } 
	      
	          
	}
	cout <<"Custo: "<< soma << endl;

}
	
	


int main()
{
	list<no> adj[100];
	int u, v, p;
	int nV, Or, S;
    list<no>::iterator P;

	cin >> nV >> Or >> S;
	cin >> u >> v >> p;
	while(u != -1 && v != -1 && p != -1)
	{
		cria_aresta(adj, u, v, p, Or);
		cin >> u >> v >> p;
	}

	prim(adj, nV, S);

	//for(int i = 0; i < nV; i++)
	//	for(P = adj[i].begin(); P != adj[i].end(); P++)
		//	cout << i << " " << P->v << endl;
	

	return 0;
}

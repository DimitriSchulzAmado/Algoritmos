#include<iostream> 
#include<list> 

using namespace std;

struct no
{
	int v;
	int peso;
};


void cria_aresta(list<no>adj[], int u, int v, int p, int orientado)
{

	no aux; // struct auxiliar
	

	
		aux.v = v; 
		aux.peso = p;
		adj[u].push_back(aux);//origem receve a struct aux contendo o destino e o peso
		if(orientado == 0)
		{
			aux.v = u;
			adj[v].push_back(aux);
		}
			
	
	
}


int main()
{
    int u, v, p; //origem, destino, peso
    int nV, Or;//numero de v�rtices e orientado
    list<no> adj[100]; // lista de adj
    list<no>::iterator P; // iterator P
    
    cin >> nV;
    cin >> Or;
    while(Or!= 1 && Or != 0)
    	cin >> Or;
    
    for(int i = 0; i < 100; i++)
	{
		cin >> u >> v >> p;
		if(u==-1 && v == -1 && p == -1)
			i = 101;
		else
		cria_aresta(adj,u,v,p,Or); // chamada da fun��o para criar as arestas
		
	}
	
	cout << endl;
	
	for(int i = 0; i < nV; i++) // mostrando o grafo
		for(P = adj[i].begin(); P!= adj[i].end(); P++)
			cout << i <<" "<< P->v <<" "<< P->peso << endl;
	
	return 0;
}